package modela1.reo_comelon_simulator.repository.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "bitacora_registro_presos")
public class BitacoraRegistroPresos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer id_registro_presos;
    private Date fecha;
    private Time hora;
    private Boolean es_insert;
}
