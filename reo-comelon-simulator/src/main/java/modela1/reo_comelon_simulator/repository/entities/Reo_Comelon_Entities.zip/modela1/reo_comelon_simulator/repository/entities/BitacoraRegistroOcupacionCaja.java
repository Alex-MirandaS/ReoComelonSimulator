package modela1.reo_comelon_simulator.repository.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "bitacora_registro_ocupacion_caja")
public class BitacoraRegistroOcupacionCaja {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer id_ocupacion_caja;
    private Date fecha;
    private Time hora;
    private Boolean es_insert;
}
