package modela1.reo_comelon_simulator.repository.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "registro_simulacion")
public class RegistroSimulacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer id_registro_presos;
    private Integer id_bodega;
    private String nombre;
    private Integer dias;
    private Date fecha_inicio;
    private Date fecha_fin;
    private Boolean es_premium;
    private Double presupuesto;
    private Double perdida;
}
