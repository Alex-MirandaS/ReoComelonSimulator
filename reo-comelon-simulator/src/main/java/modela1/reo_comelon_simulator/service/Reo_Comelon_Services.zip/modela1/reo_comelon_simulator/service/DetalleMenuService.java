package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.dto.response.ResponseSuccessfullyDto;
import modela1.reo_comelon_simulator.dto.response.DetalleMenuDto;
import modela1.reo_comelon_simulator.repository.entities.DetalleMenu;
import modela1.reo_comelon_simulator.repository.crud.DetalleMenuCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class DetalleMenuService {

    private final DetalleMenuCrud detalle_menuCrud;

    public ResponseSuccessfullyDto getAllDetalleMenu() {
        List<DetalleMenu> list = detalle_menuCrud.findAll();
        if (list.isEmpty()) {
            throw new BusinessException(HttpStatus.NOT_FOUND, "No se encontraron registros");
        }
        return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).body(list).build();
    }

    public ResponseSuccessfullyDto getDetalleMenuById(Integer id) {
        Optional<DetalleMenu> optional = detalle_menuCrud.findById(id);
        if (optional.isEmpty()) {
            throw new BusinessException(HttpStatus.NOT_FOUND, "Registro no encontrado");
        }
        return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).body(optional.get()).build();
    }

    public ResponseSuccessfullyDto deleteDetalleMenu(Integer id) {
        Optional<DetalleMenu> optional = detalle_menuCrud.findById(id);
        if (optional.isEmpty()) {
            throw new BusinessException(HttpStatus.NOT_FOUND, "Registro no encontrado");
        }
        try {
            detalle_menuCrud.delete(optional.get());
            return ResponseSuccessfullyDto.builder().code(HttpStatus.ACCEPTED).message("Registro eliminado exitosamente").build();
        } catch (Exception e) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "Error al eliminar el registro");
        }
    }

}
