package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.dto.response.ResponseSuccessfullyDto;
import modela1.reo_comelon_simulator.dto.response.RecetaIngredienteDto;
import modela1.reo_comelon_simulator.repository.entities.RecetaIngrediente;
import modela1.reo_comelon_simulator.repository.crud.RecetaIngredienteCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class RecetaIngredienteService {

    private final RecetaIngredienteCrud receta_ingredienteCrud;

    public ResponseSuccessfullyDto getAllRecetaIngrediente() {
        List<RecetaIngrediente> list = receta_ingredienteCrud.findAll();
        if (list.isEmpty()) {
            throw new BusinessException(HttpStatus.NOT_FOUND, "No se encontraron registros");
        }
        return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).body(list).build();
    }

    public ResponseSuccessfullyDto getRecetaIngredienteById(Integer id) {
        Optional<RecetaIngrediente> optional = receta_ingredienteCrud.findById(id);
        if (optional.isEmpty()) {
            throw new BusinessException(HttpStatus.NOT_FOUND, "Registro no encontrado");
        }
        return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).body(optional.get()).build();
    }

    public ResponseSuccessfullyDto deleteRecetaIngrediente(Integer id) {
        Optional<RecetaIngrediente> optional = receta_ingredienteCrud.findById(id);
        if (optional.isEmpty()) {
            throw new BusinessException(HttpStatus.NOT_FOUND, "Registro no encontrado");
        }
        try {
            receta_ingredienteCrud.delete(optional.get());
            return ResponseSuccessfullyDto.builder().code(HttpStatus.ACCEPTED).message("Registro eliminado exitosamente").build();
        } catch (Exception e) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "Error al eliminar el registro");
        }
    }

}
