package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.repository.entities.RegistroSimulacion;
import modela1.reo_comelon_simulator.repository.crud.RegistroSimulacionCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class RegistroSimulacionService {
    private final RegistroSimulacionCrud registrosimulacionCrud;

    public RegistroSimulacion getRegistroSimulacionByIdRegistroSimulacion(Integer id) {
        Optional<RegistroSimulacion> optional = registrosimulacionCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"RegistroSimulacion not exists");
        }
        return optional.get();
    }

    public List<RegistroSimulacion> getAllRegistroSimulacionList() {
        List<RegistroSimulacion> list = registrosimulacionCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"RegistroSimulacion not exists");
        }
        return list;
    }

}