package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.dto.response.ResponseSuccessfullyDto;
import modela1.reo_comelon_simulator.dto.response.BitacoraRegistroOcupacionCajaDto;
import modela1.reo_comelon_simulator.dto.response.NewBitacoraRegistroOcupacionCajaDto;
import modela1.reo_comelon_simulator.repository.entities.BitacoraRegistroOcupacionCaja;
import modela1.reo_comelon_simulator.repository.crud.BitacoraRegistroOcupacionCajaCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;
import modela1.reo_comelon_simulator.service.OcupacionCajaService;
import modela1.reo_comelon_simulator.repository.entities.OcupacionCaja;


@Slf4j
@RequiredArgsConstructor
@Service
public class BitacoraRegistroOcupacionCajaService {
    private final BitacoraRegistroOcupacionCajaCrud bitacora_registro_ocupacion_cajaCrud;
    private final OcupacionCajaService ocupacionCajaService;


    public ResponseSuccessfullyDto createBitacoraRegistroOcupacionCaja(NewBitacoraRegistroOcupacionCajaDto newDto) {
        BitacoraRegistroOcupacionCaja obj = new BitacoraRegistroOcupacionCaja();
        obj.setOcupacionCaja(ocupacionCajaService.getOcupacionCajaByIdOcupacionCaja(newDto.getid_ocupacion_caja()));
        obj.setFecha(newDto.getFecha());
        obj.setHora(newDto.getHora());
        obj.setEsInsert(newDto.getEsInsert());
        try{
            bitacora_registro_ocupacion_cajaCrud.save(obj);
            return ResponseSuccessfullyDto.builder().code(HttpStatus.CREATED).message("BitacoraRegistroOcupacionCaja creado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al guardar el registro");
        }
    }
    public ResponseSuccessfullyDto updateBitacoraRegistroOcupacionCaja(BitacoraRegistroOcupacionCajaDto dto) {
        Optional<BitacoraRegistroOcupacionCaja> optional = bitacora_registro_ocupacion_cajaCrud.findById(dto.getId());
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"El registro no ha sido encontrado");
        }
        BitacoraRegistroOcupacionCaja obj = optional.get();
        obj.setOcupacionCaja(ocupacionCajaService.getOcupacionCajaByIdOcupacionCaja(dto.getid_ocupacion_caja()));
        obj.setFecha(dto.getFecha());
        obj.setHora(dto.getHora());
        obj.setEsInsert(dto.getEsInsert());
        try{
            bitacora_registro_ocupacion_cajaCrud.save(obj);
            log.info("Registro actualizado...");
            return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).message("BitacoraRegistroOcupacionCaja actualizado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al actualizar el registro.");
        }
    }
    public BitacoraRegistroOcupacionCaja getBitacoraRegistroOcupacionCajaByIdBitacoraRegistroOcupacionCaja(Integer id) {
        Optional<BitacoraRegistroOcupacionCaja> optional = bitacora_registro_ocupacion_cajaCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"BitacoraRegistroOcupacionCaja not exists");
        }
        return optional.get();
    }
    public List<BitacoraRegistroOcupacionCaja> getAllBitacoraRegistroOcupacionCajaList() {
        List<BitacoraRegistroOcupacionCaja> list = bitacora_registro_ocupacion_cajaCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"BitacoraRegistroOcupacionCaja not exists");
        }
        return list;
    }
}