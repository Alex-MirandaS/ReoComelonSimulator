package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.dto.response.ResponseSuccessfullyDto;
import modela1.reo_comelon_simulator.dto.response.BitacoraRegistroPresosDto;
import modela1.reo_comelon_simulator.dto.response.NewBitacoraRegistroPresosDto;
import modela1.reo_comelon_simulator.repository.entities.BitacoraRegistroPresos;
import modela1.reo_comelon_simulator.repository.crud.BitacoraRegistroPresosCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;
import modela1.reo_comelon_simulator.service.RegistroPresosService;
import modela1.reo_comelon_simulator.repository.entities.RegistroPresos;


@Slf4j
@RequiredArgsConstructor
@Service
public class BitacoraRegistroPresosService {
    private final BitacoraRegistroPresosCrud bitacora_registro_presosCrud;
    private final RegistroPresosService registroPresosService;


    public ResponseSuccessfullyDto createBitacoraRegistroPresos(NewBitacoraRegistroPresosDto newDto) {
        BitacoraRegistroPresos obj = new BitacoraRegistroPresos();
        obj.setRegistroPresos(registroPresosService.getRegistroPresosByIdRegistroPresos(newDto.getid_registro_presos()));
        obj.setFecha(newDto.getFecha());
        obj.setHora(newDto.getHora());
        obj.setEsInsert(newDto.getEsInsert());
        try{
            bitacora_registro_presosCrud.save(obj);
            return ResponseSuccessfullyDto.builder().code(HttpStatus.CREATED).message("BitacoraRegistroPresos creado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al guardar el registro");
        }
    }
    public ResponseSuccessfullyDto updateBitacoraRegistroPresos(BitacoraRegistroPresosDto dto) {
        Optional<BitacoraRegistroPresos> optional = bitacora_registro_presosCrud.findById(dto.getId());
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"El registro no ha sido encontrado");
        }
        BitacoraRegistroPresos obj = optional.get();
        obj.setRegistroPresos(registroPresosService.getRegistroPresosByIdRegistroPresos(dto.getid_registro_presos()));
        obj.setFecha(dto.getFecha());
        obj.setHora(dto.getHora());
        obj.setEsInsert(dto.getEsInsert());
        try{
            bitacora_registro_presosCrud.save(obj);
            log.info("Registro actualizado...");
            return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).message("BitacoraRegistroPresos actualizado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al actualizar el registro.");
        }
    }
    public BitacoraRegistroPresos getBitacoraRegistroPresosByIdBitacoraRegistroPresos(Integer id) {
        Optional<BitacoraRegistroPresos> optional = bitacora_registro_presosCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"BitacoraRegistroPresos not exists");
        }
        return optional.get();
    }
    public List<BitacoraRegistroPresos> getAllBitacoraRegistroPresosList() {
        List<BitacoraRegistroPresos> list = bitacora_registro_presosCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"BitacoraRegistroPresos not exists");
        }
        return list;
    }
}