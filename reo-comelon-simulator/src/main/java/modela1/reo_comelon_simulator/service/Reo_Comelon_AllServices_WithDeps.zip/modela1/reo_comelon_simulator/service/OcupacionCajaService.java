package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.repository.entities.OcupacionCaja;
import modela1.reo_comelon_simulator.repository.crud.OcupacionCajaCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class OcupacionCajaService {
    private final OcupacionCajaCrud ocupacioncajaCrud;

    public OcupacionCaja getOcupacionCajaByIdOcupacionCaja(Integer id) {
        Optional<OcupacionCaja> optional = ocupacioncajaCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"OcupacionCaja not exists");
        }
        return optional.get();
    }

    public List<OcupacionCaja> getAllOcupacionCajaList() {
        List<OcupacionCaja> list = ocupacioncajaCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"OcupacionCaja not exists");
        }
        return list;
    }

}