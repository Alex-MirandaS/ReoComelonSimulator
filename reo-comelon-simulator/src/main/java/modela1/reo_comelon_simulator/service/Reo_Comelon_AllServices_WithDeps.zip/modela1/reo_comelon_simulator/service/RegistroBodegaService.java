package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.repository.entities.RegistroBodega;
import modela1.reo_comelon_simulator.repository.crud.RegistroBodegaCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class RegistroBodegaService {
    private final RegistroBodegaCrud registrobodegaCrud;

    public RegistroBodega getRegistroBodegaByIdRegistroBodega(Integer id) {
        Optional<RegistroBodega> optional = registrobodegaCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"RegistroBodega not exists");
        }
        return optional.get();
    }

    public List<RegistroBodega> getAllRegistroBodegaList() {
        List<RegistroBodega> list = registrobodegaCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"RegistroBodega not exists");
        }
        return list;
    }

}