package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.repository.entities.Ingrediente;
import modela1.reo_comelon_simulator.repository.crud.IngredienteCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class IngredienteService {
    private final IngredienteCrud ingredienteCrud;

    public Ingrediente getIngredienteByIdIngrediente(Integer id) {
        Optional<Ingrediente> optional = ingredienteCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"Ingrediente not exists");
        }
        return optional.get();
    }

    public List<Ingrediente> getAllIngredienteList() {
        List<Ingrediente> list = ingredienteCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"Ingrediente not exists");
        }
        return list;
    }

}