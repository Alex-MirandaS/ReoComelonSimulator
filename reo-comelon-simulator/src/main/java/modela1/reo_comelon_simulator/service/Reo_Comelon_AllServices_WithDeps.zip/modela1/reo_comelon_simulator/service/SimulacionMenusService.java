package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.dto.response.ResponseSuccessfullyDto;
import modela1.reo_comelon_simulator.dto.response.SimulacionMenusDto;
import modela1.reo_comelon_simulator.dto.response.NewSimulacionMenusDto;
import modela1.reo_comelon_simulator.repository.entities.SimulacionMenus;
import modela1.reo_comelon_simulator.repository.crud.SimulacionMenusCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;
import modela1.reo_comelon_simulator.service.RegistroSimulacionService;
import modela1.reo_comelon_simulator.repository.entities.RegistroSimulacion;
import modela1.reo_comelon_simulator.service.MenuService;
import modela1.reo_comelon_simulator.repository.entities.Menu;


@Slf4j
@RequiredArgsConstructor
@Service
public class SimulacionMenusService {
    private final SimulacionMenusCrud simulacion_menusCrud;
    private final RegistroSimulacionService registroSimulacionService;
    private final MenuService menuService;


    public ResponseSuccessfullyDto createSimulacionMenus(NewSimulacionMenusDto newDto) {
        SimulacionMenus obj = new SimulacionMenus();
        obj.setSimulacion(simulacionService.getSimulacionByIdSimulacion(newDto.getid_simulacion()));
        obj.setMenu(menuService.getMenuByIdMenu(newDto.getid_menu()));
        try{
            simulacion_menusCrud.save(obj);
            return ResponseSuccessfullyDto.builder().code(HttpStatus.CREATED).message("SimulacionMenus creado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al guardar el registro");
        }
    }
    public ResponseSuccessfullyDto updateSimulacionMenus(SimulacionMenusDto dto) {
        Optional<SimulacionMenus> optional = simulacion_menusCrud.findById(dto.getId());
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"El registro no ha sido encontrado");
        }
        SimulacionMenus obj = optional.get();
        obj.setSimulacion(simulacionService.getSimulacionByIdSimulacion(dto.getid_simulacion()));
        obj.setMenu(menuService.getMenuByIdMenu(dto.getid_menu()));
        try{
            simulacion_menusCrud.save(obj);
            log.info("Registro actualizado...");
            return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).message("SimulacionMenus actualizado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al actualizar el registro.");
        }
    }
    public SimulacionMenus getSimulacionMenusByIdSimulacionMenus(Integer id) {
        Optional<SimulacionMenus> optional = simulacion_menusCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"SimulacionMenus not exists");
        }
        return optional.get();
    }
    public List<SimulacionMenus> getAllSimulacionMenusList() {
        List<SimulacionMenus> list = simulacion_menusCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"SimulacionMenus not exists");
        }
        return list;
    }
}