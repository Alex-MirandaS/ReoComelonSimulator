package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.repository.entities.TipoPreso;
import modela1.reo_comelon_simulator.repository.crud.TipoPresoCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class TipoPresoService {
    private final TipoPresoCrud tipopresoCrud;

    public TipoPreso getTipoPresoByIdTipoPreso(Integer id) {
        Optional<TipoPreso> optional = tipopresoCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"TipoPreso not exists");
        }
        return optional.get();
    }

    public List<TipoPreso> getAllTipoPresoList() {
        List<TipoPreso> list = tipopresoCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"TipoPreso not exists");
        }
        return list;
    }

}