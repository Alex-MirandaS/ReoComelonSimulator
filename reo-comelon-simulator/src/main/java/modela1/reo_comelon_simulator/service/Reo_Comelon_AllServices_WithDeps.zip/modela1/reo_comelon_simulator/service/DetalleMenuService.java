package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.dto.response.ResponseSuccessfullyDto;
import modela1.reo_comelon_simulator.dto.response.DetalleMenuDto;
import modela1.reo_comelon_simulator.dto.response.NewDetalleMenuDto;
import modela1.reo_comelon_simulator.repository.entities.DetalleMenu;
import modela1.reo_comelon_simulator.repository.crud.DetalleMenuCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;
import modela1.reo_comelon_simulator.service.MenuService;
import modela1.reo_comelon_simulator.repository.entities.Menu;
import modela1.reo_comelon_simulator.service.RecetaService;
import modela1.reo_comelon_simulator.repository.entities.Receta;


@Slf4j
@RequiredArgsConstructor
@Service
public class DetalleMenuService {
    private final DetalleMenuCrud detalle_menuCrud;
    private final MenuService menuService;
    private final RecetaService recetaService;


    public ResponseSuccessfullyDto createDetalleMenu(NewDetalleMenuDto newDto) {
        DetalleMenu obj = new DetalleMenu();
        obj.setMenu(menuService.getMenuByIdMenu(newDto.getid_menu()));
        obj.setRecetaDes(recetaDesService.getRecetaDesByIdRecetaDes(newDto.getid_receta_des()));
        obj.setRecetaLunch(recetaLunchService.getRecetaLunchByIdRecetaLunch(newDto.getid_receta_lunch()));
        obj.setRecetaCena(recetaCenaService.getRecetaCenaByIdRecetaCena(newDto.getid_receta_cena()));
        try{
            detalle_menuCrud.save(obj);
            return ResponseSuccessfullyDto.builder().code(HttpStatus.CREATED).message("DetalleMenu creado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al guardar el registro");
        }
    }
    public ResponseSuccessfullyDto updateDetalleMenu(DetalleMenuDto dto) {
        Optional<DetalleMenu> optional = detalle_menuCrud.findById(dto.getId());
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"El registro no ha sido encontrado");
        }
        DetalleMenu obj = optional.get();
        obj.setMenu(menuService.getMenuByIdMenu(dto.getid_menu()));
        obj.setRecetaDes(recetaDesService.getRecetaDesByIdRecetaDes(dto.getid_receta_des()));
        obj.setRecetaLunch(recetaLunchService.getRecetaLunchByIdRecetaLunch(dto.getid_receta_lunch()));
        obj.setRecetaCena(recetaCenaService.getRecetaCenaByIdRecetaCena(dto.getid_receta_cena()));
        try{
            detalle_menuCrud.save(obj);
            log.info("Registro actualizado...");
            return ResponseSuccessfullyDto.builder().code(HttpStatus.OK).message("DetalleMenu actualizado exitosamente").build();
        }catch (Exception exception){
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Error al actualizar el registro.");
        }
    }
    public DetalleMenu getDetalleMenuByIdDetalleMenu(Integer id) {
        Optional<DetalleMenu> optional = detalle_menuCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"DetalleMenu not exists");
        }
        return optional.get();
    }
    public List<DetalleMenu> getAllDetalleMenuList() {
        List<DetalleMenu> list = detalle_menuCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"DetalleMenu not exists");
        }
        return list;
    }
}