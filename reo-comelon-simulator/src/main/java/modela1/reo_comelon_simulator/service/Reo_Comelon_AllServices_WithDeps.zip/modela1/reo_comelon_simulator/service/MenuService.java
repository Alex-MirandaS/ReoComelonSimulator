package modela1.reo_comelon_simulator.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

import modela1.reo_comelon_simulator.repository.entities.Menu;
import modela1.reo_comelon_simulator.repository.crud.MenuCrud;
import ayd.proyecto1.fastdelivery.exception.BusinessException;

@Slf4j
@RequiredArgsConstructor
@Service
public class MenuService {
    private final MenuCrud menuCrud;

    public Menu getMenuByIdMenu(Integer id) {
        Optional<Menu> optional = menuCrud.findById(id);
        if(optional.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"Menu not exists");
        }
        return optional.get();
    }

    public List<Menu> getAllMenuList() {
        List<Menu> list = menuCrud.findAll();
        if(list.isEmpty()){
            throw new BusinessException(HttpStatus.NOT_FOUND,"Menu not exists");
        }
        return list;
    }

}